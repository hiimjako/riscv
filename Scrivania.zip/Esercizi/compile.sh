#fork compilatore riscV
#linker con nome 
#-o oggetto con nome
#.s script
riscv64-unknown-elf-as -g -o $1.o $1.s
#lo carico ed eseguo
riscv64-unknown-elf-ld -o $1 $1.o
#rimuvo l'oggetto che non serve più
rm -r *.o
