echo target remote localhost:2223

sleep 1s

riscv64-unknown-elf-gdb $1



